# Third-party components

## sni-spoof-rs (SNI spoofing helper)

The SNI spoofing forwarder and SNI scanner bundled with this panel are the
`sni-spoof-rs` binary, built unmodified from source:

- Project: https://github.com/therealaleph/sni-spoofing-rust (v1.0.2)
- Method: DPI bypass via a fake TLS ClientHello, originally by @patterniha
  (https://github.com/patterniha/SNI-Spoofing). All credit for the technique
  goes to @patterniha.
- License: MIT.

The candidate SNI list in `backend/snilist.txt` is taken from that project's
`data/scan-snis.txt` (MIT).
