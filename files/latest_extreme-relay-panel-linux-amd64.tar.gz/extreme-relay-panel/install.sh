#!/usr/bin/env bash
# DokodemoDoor-eXtremeRelayPanel installer for Ubuntu 24.04+.
#
# Online:   bash install.sh
# Offline:  bash install.sh --bundle extreme-relay-panel-linux-amd64-offline.tar.gz
#           (or run ./install.sh from inside an extracted bundle)
# Options:  --port N --user NAME --pass PASSWORD --path /secret/   (skip the prompts)
# Remove:   bash install.sh uninstall
set -euo pipefail

# GitHub repository that hosts the release files. Set this before publishing.
REPO="OWNER/REPO"
VERSION="latest"   # or a tag such as v1.0.0

APP=extreme-relay-panel
DIR=/opt/$APP
BIN=$DIR/bin/$APP
UNIT_DIR=/etc/systemd/system

say()  { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31mxx\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "run as root (sudo bash install.sh)"
command -v systemctl >/dev/null && [ -d /run/systemd/system ] || die "systemd is required"

case "$(uname -m)" in
  x86_64|amd64) ARCH=amd64 ;;
  aarch64|arm64) ARCH=arm64 ;;
  *) die "unsupported CPU: $(uname -m)" ;;
esac

if [ -r /etc/os-release ]; then
  . /etc/os-release
  if [ "${ID:-}" != "ubuntu" ] || [ "${VERSION_ID%%.*}" -lt 24 ] 2>/dev/null; then
    warn "tested on Ubuntu 24.04 and newer; this is ${PRETTY_NAME:-unknown}"
  fi
fi

uninstall() {
  say "stopping services"
  for u in $(systemctl list-units --all --plain --no-legend "$APP-proc@*" | awk '{print $1}'); do
    systemctl disable --now "$u" >/dev/null 2>&1 || true
  done
  systemctl disable --now $APP.service >/dev/null 2>&1 || true
  nft delete table inet erp_traffic >/dev/null 2>&1 || true
  rm -f $UNIT_DIR/$APP.service "$UNIT_DIR/$APP-proc@.service" /usr/local/bin/$APP
  systemctl daemon-reload
  read -r -p "Delete $DIR with all settings, configs and cores? [y/N] " a
  if [ "${a,,}" = "y" ]; then rm -rf "$DIR"; say "removed $DIR"; else say "kept $DIR"; fi
  say "uninstalled"
  exit 0
}

BUNDLE="" PORT="" USER_NAME="" PASS="" WEBPATH=""
while [ $# -gt 0 ]; do
  case "$1" in
    uninstall) uninstall ;;
    --bundle) BUNDLE="$2"; shift 2 ;;
    --port) PORT="$2"; shift 2 ;;
    --user) USER_NAME="$2"; shift 2 ;;
    --pass) PASS="$2"; shift 2 ;;
    --path) WEBPATH="$2"; shift 2 ;;
    -h|--help) sed -n '2,10p' "$0"; exit 0 ;;
    *) die "unknown option: $1" ;;
  esac
done

WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

# Find the release files: a given bundle, the folder this script sits in, or GitHub.
if [ -n "$BUNDLE" ]; then
  [ -f "$BUNDLE" ] || die "bundle not found: $BUNDLE"
  tar -xzf "$BUNDLE" -C "$WORK"
  SRC=$(dirname "$(find "$WORK" -path "*/bin/$APP" -type f | head -1)")/..
elif [ -x "$HERE/bin/$APP" ]; then
  SRC=$HERE
else
  [ "$REPO" != "OWNER/REPO" ] || die "REPO is not set in this script; use --bundle with a downloaded release file"
  if [ "$VERSION" = "latest" ]; then
    URL="https://github.com/$REPO/releases/latest/download/$APP-linux-$ARCH.tar.gz"
  else
    URL="https://github.com/$REPO/releases/download/$VERSION/$APP-linux-$ARCH.tar.gz"
  fi
  say "downloading $URL"
  curl -fL --retry 3 --connect-timeout 15 -o "$WORK/release.tar.gz" "$URL" \
    || die "download failed; download the release file elsewhere and run: bash install.sh --bundle FILE"
  tar -xzf "$WORK/release.tar.gz" -C "$WORK"
  SRC=$(dirname "$(find "$WORK" -path "*/bin/$APP" -type f | head -1)")/..
fi
[ -x "$SRC/bin/$APP" ] || die "release files are incomplete (bin/$APP missing)"
SRC=$(cd "$SRC" && pwd)

file "$SRC/bin/$APP" 2>/dev/null | grep -q "$( [ $ARCH = amd64 ] && echo x86-64 || echo aarch64 )" \
  || [ ! -x "$(command -v file)" ] || die "the panel binary is not built for $ARCH"

say "package version: $("$SRC/bin/$APP" version 2>/dev/null || echo unknown)"

UPGRADE=0
[ -f "$DIR/data/panel.db" ] && UPGRADE=1

say "installing to $DIR"
systemctl stop $APP.service >/dev/null 2>&1 || true
mkdir -p "$DIR/bin"
install -m 0755 "$SRC/bin/$APP" "$BIN.new" && mv -f "$BIN.new" "$BIN"
ln -sf "$BIN" /usr/local/bin/$APP
# SNI spoofing helper (bundled). Optional: the panel runs without it, only SNI spoofing needs it.
if [ -f "$SRC/bin/sni-spoof-rs" ]; then
  install -m 0755 "$SRC/bin/sni-spoof-rs" "$DIR/bin/sni-spoof-rs.new" && mv -f "$DIR/bin/sni-spoof-rs.new" "$DIR/bin/sni-spoof-rs"
fi
install -m 0644 "$SRC/systemd/$APP.service" "$UNIT_DIR/$APP.service"
install -m 0644 "$SRC/systemd/$APP-proc@.service" "$UNIT_DIR/$APP-proc@.service"
systemctl daemon-reload

# Traffic counting uses nftables. The panel works without it, but shows no traffic numbers.
if ! command -v nft >/dev/null 2>&1; then
  say "installing nftables (traffic counting)"
  (DEBIAN_FRONTEND=noninteractive apt-get install -y nftables >/dev/null 2>&1) \
    || warn "could not install nftables; traffic counting stays off until it is installed (apt install nftables)"
fi

# Offline bundles may carry the cores and geo files.
for f in "$SRC"/cores/Xray-linux-*.zip; do [ -f "$f" ] && { say "installing Xray from bundle"; "$BIN" install-core xray "$f"; }; done
for f in "$SRC"/cores/sing-box-*.tar.gz; do [ -f "$f" ] && { say "installing sing-box from bundle"; "$BIN" install-core sing-box "$f"; }; done
for core in xray sing-box; do
  if [ -d "$SRC/geo/$core" ]; then
    mkdir -p "$DIR/geo/$core"
    cp -n "$SRC/geo/$core"/* "$DIR/geo/$core/" 2>/dev/null || true
  fi
done

if [ $UPGRADE -eq 0 ]; then
  if [ -z "$PORT" ]; then read -r -p "Panel port [2096]: " PORT; PORT=${PORT:-2096}; fi
  [[ "$PORT" =~ ^[0-9]+$ ]] && [ "$PORT" -ge 1 ] && [ "$PORT" -le 65535 ] || die "bad port: $PORT"
  if ss -Htln "sport = :$PORT" 2>/dev/null | grep -q .; then die "port $PORT is already in use"; fi
  if [ -z "$USER_NAME" ]; then read -r -p "Admin username [admin]: " USER_NAME; USER_NAME=${USER_NAME:-admin}; fi
  if [ -z "$PASS" ]; then
    read -r -s -p "Admin password (8+ characters, empty = generate): " PASS; echo
    # "|| true": head closes the pipe early, which would otherwise end the script under pipefail.
    if [ -z "$PASS" ]; then PASS=$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 16 || true); fi
  fi
  [ ${#PASS} -ge 8 ] || die "password needs 8+ characters"
  # The panel only answers on its path, so the path is never empty.
  if [ -z "$WEBPATH" ]; then read -r -p "Panel path, e.g. /my-panel/ [empty = random]: " WEBPATH; fi
  case "$WEBPATH" in ""|"/") WEBPATH="/$(LC_ALL=C tr -dc 'a-z0-9' </dev/urandom | head -c 12 || true)/" ;; esac
  "$BIN" init --port "$PORT" --user "$USER_NAME" --pass "$PASS" --path "$WEBPATH" >/dev/null
fi

systemctl enable --now $APP.service >/dev/null
sleep 1
systemctl is-active --quiet $APP.service || { journalctl -u $APP.service -n 20 --no-pager; die "the panel did not start"; }

[ $UPGRADE -eq 1 ] && say "upgraded; outbounds and tunnels kept running"

# Address of this server: the IPv4 on the default-route interface when it is public. A lookup service
# only sees the address traffic leaves from, which can differ (NAT, routed egress), so it is used
# only when the interface address is private.
IP=$(ip -4 -o route get 1.1.1.1 2>/dev/null | awk '{for (i = 1; i < NF; i++) if ($i == "src") print $(i + 1)}')
if [[ ! "$IP" =~ ^[0-9]+(\.[0-9]+){3}$ ]] || [[ "$IP" =~ ^(10\.|127\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.|100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.) ]]; then
  IP=$(curl -4 -fsS --max-time 4 https://ipinfo.io/ip 2>/dev/null || true)
fi
[[ "$IP" =~ ^[0-9]+(\.[0-9]+){3}$ ]] || IP=""
iv() { "$BIN" info ${IP:+--host "$IP"} | awk -v k="$1:" '$1==k{print $2}'; }
URL=$(iv url) HOST=$(iv host) PORT_NOW=$(iv port) PATH_NOW=$(iv path) ADMIN=$(iv username)

# Check that the panel really answers on its path.
CODE=$(curl -ks -o /dev/null -w '%{http_code}' --max-time 5 "$(echo "$URL" | sed -E "s#//[^/]+#//127.0.0.1:$PORT_NOW#")" || true)
[ "$CODE" = 200 ] || warn "the panel did not answer 200 on its path (got ${CODE:-none}); check: journalctl -u $APP -n 30"

if command -v ufw >/dev/null && ufw status 2>/dev/null | grep -q "Status: active"; then
  warn "ufw is active: allow the panel with: ufw allow $PORT_NOW/tcp (and each tunnel port you create)"
fi

if [ $UPGRADE -eq 1 ]; then
  PWTXT="(unchanged, the one you set before)" PWNOTE=""
else
  PWTXT="$PASS" PWNOTE=$'\n     Save the password now. It is stored hashed and cannot be shown again.'
fi
B=$'\033[1m' C=$'\033[1;36m' R=$'\033[0m'
LINE="=============================================================="
cat <<EOF

$C$LINE$R
$B  DokodemoDoor-eXtremeRelayPanel is installed and running$R
$C$LINE$R

$B  1) Login$R
     Username : $ADMIN
     Password : $PWTXT$PWNOTE

$B  2) Panel address$R  (the panel answers only on this path)
     IP   : $HOST
     Port : $PORT_NOW
     Path : $PATH_NOW

     Open this link in your browser:

     $URL

$B  3) Terminal commands$R  (run as root)

     Show the link, port, path and username again:
       $APP info

     Panel not opening after a wrong domain or HTTPS setting? Go back to the IP link:
       $APP reset-domain && systemctl restart $APP

     Change the admin username and password:
       $APP reset-admin --user NAME --pass NEWPASS

     Change the panel port and path (the panel must be restarted after):
       $APP reset-admin --user NAME --pass PASS --port 4000 --path /new-path/
       systemctl restart $APP

     Panel service and log:
       systemctl status $APP        (also: start, stop, restart)
       journalctl -u $APP -f

     Outbounds and tunnels (each one is its own service: ob-1, ob-2, ... tn-1, tn-2, ...):
       systemctl list-units '$APP-proc@*'
       systemctl status $APP-proc@ob-1
       journalctl -u '$APP-proc@*' -f

     Install a core from a file:
       $APP install-core xray /path/Xray-linux-64.zip
       $APP install-core sing-box /path/sing-box-VERSION-linux-amd64.tar.gz

     Back up or restore the settings (encrypted with a password you choose, 8+ characters):
       $APP backup --file backup.erp --pass 'PASSWORD'
       $APP restore --file backup.erp --pass 'PASSWORD'
       systemctl restart $APP                      (the restore is applied at this restart)

     Other:
       $APP version
       bash $0 uninstall

$C$LINE$R
EOF
