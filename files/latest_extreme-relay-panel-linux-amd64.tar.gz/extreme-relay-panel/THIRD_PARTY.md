# Third-party components

## sni-spoof-rs (SNI spoofing helper)

The SNI spoofing forwarder and SNI scanner bundled with this panel are the
`sni-spoof-rs` binary, built unmodified from source:

- Project: https://github.com/therealaleph/sni-spoofing-rust (v1.0.2)
- Method: DPI bypass via a fake TLS ClientHello, originally by @patterniha
  (https://github.com/patterniha/SNI-Spoofing). All credit for the technique
  goes to @patterniha.
- License: MIT.

The candidate SNI list in `backend/snilist.txt` is taken from that project's
`data/scan-snis.txt` (MIT).

## WatTunnel (SNI spoofing methods)

`backend/wat/` contains `desync.go`, `desync_linux.go` and `probe.go` copied from WatTunnel (one addition in
`desync_linux.go`: a packet filter call), plus `rawtcp.go` and `bpf_linux.go` of our own. `backend/spoofd.go` uses them as the forwarder behind the SNI spoofing methods.

- Project: https://github.com/JohnWatsoon/WatTunnel (3.0.0)
- Copyright (c) 2026 Amirreza, MIT License (copy in `backend/wat/LICENSE`). Its own source says the base method was
  reverse-engineered from @patterniha's SNI-Spoofing.
